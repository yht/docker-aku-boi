Fitra 'Rabitya' Aditya (fitra@g.pl)
